import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class bush here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class bush extends Actor
{  
    /**
     * Act - do whatever the bush wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    
    
    public bush(){
    
    
   
    
    
    
    
    }
    public void act()
    {
        
    }
    
    

}
